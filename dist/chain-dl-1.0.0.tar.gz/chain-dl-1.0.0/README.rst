Chain-dl
=======================

A chained viedeos downloader based on the amazing youtube-dl.

It fetches videos URL from a website's iframes and downloads them.

See `the full README.md guide <https://github.com/encein42/chain-dl/blob/master/README.md>`_
 and `the exepmle configuration file <https://github.com/encein42/chain-dl/blob/master/chain-dl/dl_config.ini>`_.
